package com.tnsif.oopsconcept;

public class Executor {

	public static void main(String[] args) {
		
		EncapsulationDemo ed = new EncapsulationDemo();
		ed.setName("Rohit Sharma");
		ed.setAge(37);
		ed.setJersyNo(45);
		
		System.out.println(ed);
	}

}
